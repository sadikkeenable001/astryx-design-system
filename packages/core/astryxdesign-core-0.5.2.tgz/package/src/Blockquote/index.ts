// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Imports from Blockquote.tsx
 * @output Exports Blockquote component and props type
 * @position Package entry point for Blockquote
 *
 * SYNC: When modified, update /packages/core/src/Blockquote/Blockquote.doc.mjs
 */

export {Blockquote} from './Blockquote';
export type {BlockquoteProps} from './Blockquote';
