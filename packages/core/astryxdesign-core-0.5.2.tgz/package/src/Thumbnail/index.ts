// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file Thumbnail component barrel export
 */

export {Thumbnail} from './Thumbnail';
export type {ThumbnailProps} from './Thumbnail';
