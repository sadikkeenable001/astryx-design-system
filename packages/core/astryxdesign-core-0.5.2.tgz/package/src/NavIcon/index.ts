// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Imports from NavIcon.tsx
 * @output Exports NavIcon component and types
 * @position Entry point for NavIcon module
 *
 * SYNC: When modified, update /packages/core/src/NavIcon/NavIcon.doc.mjs
 */

export {NavIcon} from './NavIcon';
export type {NavIconProps} from './NavIcon';
