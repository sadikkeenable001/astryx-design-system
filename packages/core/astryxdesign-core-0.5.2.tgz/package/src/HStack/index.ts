// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input HStack component source
 * @output Exports HStack and its props type
 * @position Entry point for @astryxdesign/core/HStack subpath export
 */

export {HStack, type HStackProps} from './HStack';
