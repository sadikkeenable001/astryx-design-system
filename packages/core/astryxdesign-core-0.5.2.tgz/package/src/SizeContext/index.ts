// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input SizeContext.ts
 * @output Re-exports size context utilities
 * @position Public entry point for @astryxdesign/core/SizeContext
 */

export {
  SizeContext,
  SizeProvider,
  useSize,
  type ElementSize,
} from './SizeContext';
