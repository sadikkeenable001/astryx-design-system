// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports IconButton component and types from IconButton.tsx
 * @output Exports IconButton, IconButtonProps
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/IconButton/IconButton.doc.mjs
 */

export {IconButton} from './IconButton';
export type {IconButtonProps} from './IconButton';
