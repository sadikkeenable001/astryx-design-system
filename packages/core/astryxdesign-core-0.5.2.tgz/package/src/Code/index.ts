// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Code component source
 * @output Exports Code and its props type
 * @position Entry point for @astryxdesign/core/Code subpath export
 */

export {Code, type CodeProps, type CodeColor, type CodeSize} from './Code';
