// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Carousel component
 * @output Re-exports Carousel and its props type
 * @position Public entry point for the Carousel module
 */

export {Carousel} from './Carousel';
export type {CarouselProps, CarouselHandle} from './Carousel';
