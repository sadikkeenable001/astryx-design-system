// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from Toolbar component files
 * @output Exports Toolbar and types
 * @position Entry point for Toolbar module
 *
 * SYNC: When modified, update /packages/core/src/Toolbar/Toolbar.doc.mjs
 */

export {Toolbar} from './Toolbar';
export type {ToolbarProps, ToolbarSize} from './Toolbar';
