// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Imports from VisuallyHidden.tsx
 * @output Exports VisuallyHidden component and props type
 * @position Package entry point for VisuallyHidden
 *
 * SYNC: When modified, update /packages/core/src/VisuallyHidden/VisuallyHidden.doc.mjs
 */

export {VisuallyHidden} from './VisuallyHidden';
export type {VisuallyHiddenProps} from './VisuallyHidden';
